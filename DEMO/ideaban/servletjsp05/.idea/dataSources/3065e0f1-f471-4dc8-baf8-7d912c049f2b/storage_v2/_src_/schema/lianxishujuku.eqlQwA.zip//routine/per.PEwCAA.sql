create
    definer = root@localhost procedure per()
BEGIN
	DECLARE i INT;
	SET i = 0;
	WHILE i < 1000 DO
		INSERT INTO sales_tab VALUES(TRUNCATE(2010 + RAND() * 3, 0), TRUNCATE(1 + RAND() * 12, 0), TRUNCATE(1 + RAND() * 32, 0), TRUNCATE(1 + RAND() * 100, 2));
		SET i = i + 1;
		END WHILE;
	END;

