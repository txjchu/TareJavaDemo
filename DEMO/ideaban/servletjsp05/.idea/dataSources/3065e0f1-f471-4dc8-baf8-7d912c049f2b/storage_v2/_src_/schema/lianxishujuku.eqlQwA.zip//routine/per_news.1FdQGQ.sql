create
    definer = root@localhost procedure per_news()
BEGIN
	DECLARE i INT;
	SET i = 1;
	WHILE i <= 100 DO
		INSERT INTO news VALUES(i , CONCAT('TITLE', i), 'content', concat( CONCAT(FLOOR(2020 + (RAND() * 1)),'-',LPAD(FLOOR(10 + (RAND() * 2)),2,0),'-',LPAD(FLOOR(1 + (RAND() * 25)),2,0))));
		SET i = i + 1;
		END WHILE;
	END;

