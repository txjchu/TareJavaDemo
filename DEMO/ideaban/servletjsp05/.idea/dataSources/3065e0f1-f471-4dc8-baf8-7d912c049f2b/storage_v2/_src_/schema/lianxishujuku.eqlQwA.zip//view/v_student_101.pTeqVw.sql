create definer = root@localhost view v_student_101 as
select `lianxishujuku`.`student`.`id`      AS `id`,
       `lianxishujuku`.`student`.`name`    AS `name`,
       `lianxishujuku`.`student`.`subject` AS `subject`,
       `lianxishujuku`.`student`.`score`   AS `score`,
       `lianxishujuku`.`student`.`classid` AS `classid`
from `lianxishujuku`.`student`
where (`lianxishujuku`.`student`.`classid` = 101);

